using System;
using System.IO;
using System.Collections;
using System.Windows.Forms;
using System.Drawing;

using ICSharpCode.Core.Services;
using ICSharpCode.Core.Properties;
using ICSharpCode.Core.AddIns.Codons;
using ICSharpCode.Core.AddIns.Conditions;
using ICSharpCode.Core.AddIns;

using ICSharpCode.SharpDevelop.Services;
using ICSharpCode.SharpDevelop.Gui;


namespace sps.SharpDevelop.AddInScout
{
	
	public class AddInScoutViewContent : AbstractViewContent
	{
		string filename = "";
		Control control = null;
		
		public override Control Control {get {return control;}}
				
		public override string TabPageText {get {return "AddIns";}}
		
		public override bool IsDirty 
		{
			get {return false;}
			set {}
		}
		
		public override bool IsViewOnly {get {return true;}}
	
		IWorkbenchWindow workbenchWindow;
		public override IWorkbenchWindow WorkbenchWindow 
		{
			get {return workbenchWindow;}
			set 
			{
				workbenchWindow = value;
				if (filename == "") 
					workbenchWindow.Title = "AddInScout";
				else
					workbenchWindow.Title = filename;
			}
		}
		
		public override void Dispose()
		{
			try {
				foreach(Control ctl in Control.Controls) {ctl.Dispose();}
			} catch {
				return;
			}
		}
				
		public void SaveFile(){}
		
		public void Undo(){}

		public void Redo(){}
				
		public override void Save(){}
		
		public override void Save(string filename){}
		
		public override void Load(string filename){}
		
		public AddInScoutViewContent()
		{
			Panel p = new Panel();
			p.Dock= DockStyle.Fill;
			p.BorderStyle = BorderStyle.FixedSingle;
		
				Splitter s1 = new Splitter();
				s1.Dock = DockStyle.Left;
		
				TreeView tv = new TreeView();
				tv.Width = 300;
				tv.BorderStyle = BorderStyle.FixedSingle;
				tv.AfterSelect += new TreeViewEventHandler(this.tvSelectHandler);
				tv.Dock = DockStyle.Left;
				GetAddInTree(tv);

				Panel RightPanel = new Panel();
				RightPanel.Dock = DockStyle.Fill;
			
					Splitter hs = new Splitter();
					hs.Dock = DockStyle.Top;
			
					Panel AIPanel = new Panel();
					AIPanel.Dock = DockStyle.Top;
					AIPanel.Height = 175;
				
						AddInLV.Dock = DockStyle.Fill;
						AddInLV.GridLines = false;
						AddInLV.View = View.Details;
						AddInLV.MultiSelect = false;
						AddInLV.FullRowSelect = true;
						AddInLV.Activation = ItemActivation.OneClick;
						AddInLV.HeaderStyle = ColumnHeaderStyle.None;
						AddInLV.BorderStyle = BorderStyle.FixedSingle;
						AddInLV.ItemActivate += new EventHandler(lvHandler);
						
						AddInLabel.Dock =DockStyle.Top;
						AddInLabel.Text = "AddIn : ";
						AddInLabel.Font = new Font(AddInLabel.Font.FontFamily,AddInLabel.Font.Size*2);
						AddInLabel.Height = AddInLabel.Height*2;
						AddInLabel.FlatStyle = FlatStyle.Flat;
						AddInLabel.TextAlign = ContentAlignment.MiddleLeft;
						AddInLabel.BorderStyle = BorderStyle.FixedSingle;
						
					AIPanel.Controls.Add(AddInLV);
					AIPanel.Controls.Add(AddInLabel);
	
					Panel ExtPanel = new Panel();
					ExtPanel.Dock = DockStyle.Fill;
						
						CodonLV.Dock = DockStyle.Fill;
						CodonLV.GridLines = true;
						CodonLV.View = View.Details;
						CodonLV.FullRowSelect = true;
						CodonLV.BorderStyle = BorderStyle.FixedSingle;
			
						ExtLabel.Text = "Extension : ";
						ExtLabel.Dock =DockStyle.Top;
						ExtLabel.FlatStyle = FlatStyle.Flat;
						ExtLabel.TextAlign = ContentAlignment.MiddleLeft;
						ExtLabel.BorderStyle = BorderStyle.FixedSingle;
			
					ExtPanel.Controls.Add(CodonLV);
					ExtPanel.Controls.Add(ExtLabel);												
				
				RightPanel.Controls.Add(ExtPanel);
				RightPanel.Controls.Add(hs);
				RightPanel.Controls.Add(AIPanel);
		
			p.Controls.Add(RightPanel);
			p.Controls.Add(s1);
			p.Controls.Add(tv);

			this.control = p;
			this.ContentName = "AddIn Scout";
		}
		
		private void GetAddInTree(TreeView tv)
		{
			TreeNode tn1 = new TreeNode("Addins");
			tn1.Expand();
			TreeNode tn2;
			tv.Nodes.Add(tn1);
			IAddInTree at = AddInTreeSingleton.AddInTree;
			AddInCollection ac = at.AddIns;
			for (int i = 0; i < ac.Count; i++)
			{
				tn2 = new TreeNode(ac[i].Name );
				tn2.Tag = ac[i];
				GetExtensions(ac[i],tn2);
				tn1.Nodes.Add(tn2);
			}
		
		}
		
		private void GetExtensions(AddIn ai,TreeNode tn)
		{
			TreeNode tn2;
			AddIn.Extension ae;
			IEnumerator e = ai.Extensions.GetEnumerator();
			while (e.MoveNext())
			{
				ae = (AddIn.Extension)e.Current;
				tn2=new TreeNode(ae.Path);
				tn2.Tag = ae;
				tn.Nodes.Add(tn2);
			}
		}
		
		public void lvHandler(object sender, EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			
			ListView lv = (ListView) sender;
			ListViewItem lvi = lv.SelectedItems[0];
			
			if (lvi.Text.ToLower().Equals("url"))
			{
				string url = lvi.SubItems[1].Text;
				try	
				{
					System.Diagnostics.Process.Start("explorer",url);
				}
				catch(Exception)
				{
					MessageBox.Show("Unable to Start Browser");
				}
			}
			else if (lvi.Text.ToLower().Equals("filename"))
			{
				IFileService fileService = (IFileService) ServiceManager.Services.GetService(typeof(IFileService));
				fileService.OpenFile(lvi.SubItems[1].Text);
			}
			
			Cursor.Current = Cursors.Default;
		}
		
		private AddIn prevAi;
		public void tvSelectHandler(object sender, TreeViewEventArgs e)
		{
			
			AddIn ai;
			AddIn.Extension ext;
			TreeNode tn = e.Node;
			object taggedObj = e.Node.Tag;
			
			if (taggedObj == null) return;
			
			if (taggedObj is AddIn) 
			{
				ai = (AddIn) taggedObj;
				if (prevAi != ai)
				{
					prevAi = ai;
					GetAddInDetails(ai);
					if (tn.FirstNode != null) GetCodonDetails((AddIn.Extension )tn.FirstNode.Tag);
					else GetCodonDetails(null);
				}
			}
			else
			{
				ext = (AddIn.Extension) taggedObj;
				ai  =  (AddIn) tn.Parent.Tag;
				if (prevAi != ai)
				{
					prevAi = ai;
					GetAddInDetails(ai);
				}
				GetCodonDetails(ext);
			}
		
		}
		
		private ListView AddInLV   = new ListView();    // show addin details
		private ListView CodonLV   = new ListView();    // show codin details
		private Label AddInLabel   = new Label();       // show addin name
		private Label ExtLabel     = new Label();	    // show extension name
		
		private void GetAddInDetails(AddIn ai)
		{
			AddInLabel.Text = "AddIn : " + ai.Name;
			
			AddInLV.Columns.Clear();
			AddInLV.Columns.Add("Property",100, HorizontalAlignment.Left);
   			AddInLV.Columns.Add("Value", 500, HorizontalAlignment.Left);			
			
			ListViewItem[] items = new ListViewItem[6];
			
			items[0] = new ListViewItem("Author");
			items[0].SubItems.Add(ai.Author);
			
			items[1] = new ListViewItem("Copyright");
			items[1].SubItems.Add(ai.Copyright);
			
			items[2] = new ListViewItem("Description");
			items[2].SubItems.Add(ai.Description);
			
			items[3] = new ListViewItem("FileName");
			items[3].Font = new Font(AddInLV.Font, FontStyle.Underline);
			items[3].ForeColor = Color.Blue;
			items[3].SubItems.Add(ai.FileName);
			                         
			items[4] = new ListViewItem("Url");
			items[4].Font = new Font(AddInLV.Font,FontStyle.Underline);
			items[4].ForeColor = Color.Blue;
			items[4].SubItems.Add(ai.Url);
			
			items[5] = new ListViewItem("Version");
			items[5].SubItems.Add(ai.Version);
			
			AddInLV.Items.Clear();
			AddInLV.Items.AddRange(items);
			
			ListViewItem lvi;
			Hashtable rls = ai.RuntimeLibraries;
			foreach (DictionaryEntry rl in rls)
			{
				lvi = new ListViewItem("Runtime Library");
				lvi.SubItems.Add((string) rl.Key);
				AddInLV.Items.Add(lvi);
			}
		}
		

		private void GetCodonDetails(AddIn.Extension ext)
		{
			if (ext == null) 
			{
				ExtLabel.Text = "Extension : ";
				CodonLV.Clear();
				return;
			}
			
			ExtLabel.Text = "Extension : " + ext.Path;
			
			CodonLV.Columns.Clear();
			CodonLV.Columns.Add("Codon", 100,HorizontalAlignment.Left);
			CodonLV.Columns.Add("Codon ID", 175,HorizontalAlignment.Left);
			CodonLV.Columns.Add("Codon Class", 400,HorizontalAlignment.Left);
			CodonLV.Columns.Add("Codon Condition -> Action on Fail", 600,HorizontalAlignment.Left);
		
			ICodon c;
			ListViewItem lvi;
			
			CodonLV.Items.Clear();			
			IEnumerator e = ext.CodonCollection.GetEnumerator();
			Hashtable CondTbl = ext.Conditions;
			ConditionCollection cc;
			string ccs, ccs0;
			while (e.MoveNext())
			{
				c=(ICodon) e.Current;
				lvi = new ListViewItem(c.Name);
				lvi.SubItems.Add(c.ID);
				lvi.SubItems.Add(c.Class);
				cc = (ConditionCollection) CondTbl[c.ID];
				if (cc != null)
				{
					ccs="";
					ccs0="";
					for (int i = 0;i<cc.Count;i++)
					{
						ccs0=cc[i].ToString()+" -> "+cc[i].Action;
						if (i==0) ccs=ccs0;
						else ccs = ccs +" , " + ccs0;
					}
					if (ccs != "") lvi.SubItems.Add(ccs);
				}
				CodonLV.Items.Add(lvi);
			}
		}
	}
}
