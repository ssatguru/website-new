/*
 * SqrParser.java
 *
 * Copyright (C) 2004, Satguru P Srivastava
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.text.*;

import sidekick.*;
import errorlist.*;

import org.gjt.sp.jedit.*;
import org.gjt.sp.util.*;
import org.gjt.sp.jedit.search.*;
import org.gjt.sp.jedit.textarea.*;

import gnu.regexp.*;

//ssdbug
import java.util.*;
public class SqrParser extends SideKickParser
{

	protected static RE matcher;
	public ImageIcon  procIcon = new ImageIcon(getClass().getResource("proc.png"));
	public ImageIcon  doIcon = new ImageIcon(getClass().getResource("do.png"));
	public ImageIcon  inclIcon = new ImageIcon(getClass().getResource("incl.png"));


	public SqrParser()
	{
		super("SqrParser");
		return;
	}


 	public SideKickParsedData parse(Buffer buffer, DefaultErrorSource errorSource)
	{
		REMatch matches[]=null;
		matches=searchRE(buffer);
		return createSideKickParsedData(matches, buffer, errorSource);
	}


 	private REMatch[] searchRE(Buffer buffer)
	{
		REMatch matches[]=null;
		String ParseText;
		String ParsePattern;
		ParseText=buffer.getText(0,buffer.getLength());
		ParsePattern="^[[:blank:]]*" +
			     "(((begin-setup|end-setup|begin-heading|end-heading|begin-footing|" +
		                "end-footing|begin-program|end-program|begin-report|end-report|" +
				//"end-footing|begin-program|end-program|" +
				"begin-procedure|end-procedure|do|#include)" +  //token3
				"[[:blank:]]*" +
				"([[:graph:]]*))" +        //token4, token2
				//"([\'-_[:alnum:]]*))" +   //token4, token2
				"[[:blank:][:graph:]]*\\n)";  //token1, token0

		if (matcher==null)
		{
			try
			{
				matcher=new gnu.regexp.RE((Object)ParsePattern,gnu.regexp.RE.REG_ICASE|gnu.regexp.RE.REG_MULTILINE,org.gjt.sp.jedit.search.RESearchMatcher.RE_SYNTAX_JEDIT);
			}
			catch (REException ree)
			{
				Log.log(Log.ERROR,  this, "bad parser string"+" "+ParsePattern);
			}

		}


		matches=matcher.getAllMatches((Object)ParseText);

		return matches;
	}


 	private SideKickParsedData createSideKickParsedData(REMatch matches[], Buffer buffer, DefaultErrorSource errorSource)
	{

		String StmtValue="";
		int StmtType=0;
		int StmtStart=0;
		int StmtEnd=0;

		String SecType="";   //section type - procedure, heading, footing, setup, program, report
		boolean SecOver=true;
		ImageIcon icon=null;

		String ErrMsg;

		DefaultMutableTreeNode TopNode;
		DefaultMutableTreeNode ParentNode;

		SideKickParsedData SKParsedData;

		SqrAsset aSqrAsset=null;
		SqrAsset prevSqrAsset=null;
		int prevIndex=0;

		Position TopNodeEnd;
		TopNode= null;
		ParentNode=null;

		SKParsedData=new SideKickParsedData(buffer.getName());
		TopNode=SKParsedData.root;
		ParentNode=TopNode;

		String Token2, Token3, Token4;
		int j;
		for(int i=0;i<=matches.length-1;i++)
		{
			Token2 = matches[i].toString(2);
			Token3 = matches[i].toString(3).toLowerCase();
			Token4 = matches[i].toString(4);

			if (Token3.startsWith("begin-"))
			{
				SecType = Token3.substring(6);
				icon = procIcon;
				if (SecType.equals("procedure"))
				{
					j = Token4.indexOf('(');
					if (j>0) StmtValue=Token4.substring(0,j);
					else StmtValue=Token4;
				}
				else
					StmtValue = SecType;
				StmtType = 1;
			}
			else if (Token3.startsWith("end-"))
			{
				StmtType = 2;
			}
			else if (Token3.equals("#include"))
			{
				icon = inclIcon;
				StmtValue="include " + Token4;
				StmtType=3;
			}
			else
			{
				icon = doIcon;
				j = Token4.indexOf('(');
				if (j>0) StmtValue="do " + Token4.substring(0,j);
				else StmtValue="do " + Token4;
				StmtType = 4;
			}

			StmtStart=matches[i].getStartIndex(1);
			StmtEnd=matches[i].getEndIndex(1);

			if (StmtType ==2 )
			{
					if (prevSqrAsset != null)
						prevSqrAsset.end = buffer.createPosition(StmtStart);

					if (!(Token3.substring(4).equals(SecType)))
					{
						ErrMsg = "A '" + matches[i].toString(3) + "' found without a corresponding 'begin' statement.";
						errorSource.addError(DefaultErrorSource.ERROR,buffer.getPath(),buffer.getLineOfOffset(StmtStart),0,StmtEnd - StmtStart-1,ErrMsg);
					}
					else  SecOver = true;
			}
			else
			{
				aSqrAsset=new SqrAsset(StmtStart,StmtEnd, StmtValue, icon, buffer);
				if (StmtType == 1)
				{
					ParentNode = new DefaultMutableTreeNode(aSqrAsset);
					TopNode.add(ParentNode);
					if (!(SecOver))
					{
						int s = matches[prevIndex].getStartIndex(1);
						int e = matches[prevIndex].getEndIndex(1);
						ErrMsg = "A " + matches[prevIndex].toString(3) + " found without a corresponding 'end-' statement.";
						errorSource.addError(DefaultErrorSource.ERROR,buffer.getPath(),buffer.getLineOfOffset(s),0,e-s-1,ErrMsg);
					}
					prevSqrAsset = aSqrAsset;
					prevIndex = i;
					SecOver=false;
				}
				else if (StmtType==3)
				{
					if (SecOver)
						TopNode.add(new DefaultMutableTreeNode(aSqrAsset));
					else
						ParentNode.add(new DefaultMutableTreeNode(aSqrAsset));
				}
				else 	ParentNode.add(new DefaultMutableTreeNode(aSqrAsset));
			}
		}
		if (!(SecOver))
		{
			int s = matches[prevIndex].getStartIndex(1);
			int e = matches[prevIndex].getEndIndex(1);
			ErrMsg = "A " + matches[prevIndex].toString(3) + " found without a corresponding 'end-' statement.";
			errorSource.addError(DefaultErrorSource.ERROR,buffer.getPath(),buffer.getLineOfOffset(s),0,e-s-1,ErrMsg);
		}

		TopNodeEnd=buffer.createPosition(buffer.getLength());
		return SKParsedData;
  }
}
